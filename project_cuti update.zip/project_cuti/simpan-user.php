<?php
include "koneksi.php";

$id 	= $_POST['id_user'];
$nama 	= $_POST['nama_email'];
$sandi 	= $_POST['sandi'];
$grup 	= $_POST['grup'];

echo "<script>
        alert('Data Berhasil Disimpan');
        window.location ='login.php';
       </script>";

$simpan = mysqli_query($koneksi, "INSERT INTO user SET id_user='$id',nama_email='$nama',sandi='$sandi',grup='$grup'");

?>