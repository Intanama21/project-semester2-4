<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
<title>Data Pengajuan Cuti</title>
    <style>
        table {
            border-collapse: collapse;
            width: 950px;
            margin: 10px auto;
            align: center;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: rgba(255,228,181);
        }
        td {
            background-color: rgba(255,255,290);
        }
    </style>
</head>
<body>
    <h2 align="center"> PENGAJUAN CUTI KARYAWAN</h2>

    <table border='1'>
        <tr>
            <th>ID Pengajuan</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Departemen</th>
            <th>Tanggal Mulai</th>
            <th>Tanggal Selesai</th>
            <th>Jenis Cuti</th>
            <th>Alasan</th>
            <th>Kelola</th>
        </tr>

        <?php
        session_start();
        if(!isset($_SESSION['id_user'])) {
            echo "<script>
                alert('Silakan login dahulu');
                window.location = '../project_cuti/login.php';
            </script>";
            exit;
        }

        $no = 1;
        $sql = mysqli_query($koneksi, "SELECT * FROM pengajuan_cuti");
        while($tampil = mysqli_fetch_array($sql)) {
        ?>
        <tr>
            <td><?php echo $tampil['id_pengajuan']; ?></td>
            <td><?php echo $tampil['nik']; ?></td>
            <td><?php echo $tampil['nama']; ?></td>
            <td><?php echo $tampil['departemen']; ?></td>
            <td><?php echo $tampil['tgl_mulai']; ?></td>
            <td><?php echo $tampil['tgl_selesai']; ?></td>
            <td><?php echo $tampil['jenis_cuti']; ?></td>
            <td><?php echo $tampil['alasan']; ?></td>
            <td align='center'><a href="form-persetujuan.php?id=<?php echo $tampil['id_pengajuan']; ?>">Approval</a></td>
        </tr>
        <?php $no++; } ?>
    </table>

    <script>
        // Fungsi untuk mengarahkan ke form-persetujuan.php dengan ID yang sesuai
        function tampil() {
            window.location.href = "form-persetujuan.php?id=<?php echo $tampil['id_pengajuan']; ?>";
        }
    </script>
</body>
</html>
