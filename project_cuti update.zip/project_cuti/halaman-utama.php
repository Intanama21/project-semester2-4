<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <style>
    .content{
      margin-left: 250px;
      background-color: rgb(244, 245, 247);
      height: 500px;
      padding-top: 5px;
    }

    tr, td{
     width: 100%;
    }
    body, ul {
    margin: 0;
    padding: 0;
    font-family: system-ui, apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    font-size: medium;
    }

    .sidebar {
    background: white;
    color: #181717;
    width: 250px;
    height: 100%;
    position: fixed;
    }

    .head {
    margin-left: 250px;
    padding: 10px;
    background-color: rgb(245, 168, 74);
    }

    .sidebar h2 {
    padding: 20px;
    }

    .sidebar ul {
    list-style: none;
    }

    .sidebar ul li {
    padding: 10px 0;
    }

    .sidebar ul li a {
    display: block;
    color: #191515;
    text-decoration: none;
    padding: 10px;
    }

    .sidebar ul li a:hover {
    background: #ffa748;
    }

    img{
      width: 250px;
      height: 100px;
    }
  </style>
</head>
<body>
  <?php
   session_start();
   if(!isset($_SESSION['id_user']))
   {
       echo "<script>
           alert('Silakan login dahulu');		
           window.location = '../project_cuti/login.php'; 
          </script>";
       exit;	
   }
   else
   {
       echo "<script>
       alert ('Selamat Datang'); 
       </script>";
   }
  ?>

  <div class="dashboard">

    <div class="sidebar">
      <img src="logo.pt.png" alt="">
      <ul>
        <li><a href="beranda.php" target="iframetarget">Beranda</a></li>
        <li><a href="tampil_karyawan.php" target="iframetarget">Data Karyawan</a></li>
        <li><a href="data_departemen.php" target="iframetarget">Data Departemen</a></li>
        <li><a href="pengajuan-cuti.php" target="iframetarget">Pengajuan Cuti</a></li>
        <li><a href="cuti.php" target="iframetarget">Cuti Karyawan</a></li>
        <li><a href="" onclick="logout()">Logout</a></li>
      </ul>
    </div>

    <div class="head">
      <table border="0">
        <tr>
          <td><h3>PT SANNOHASHI MANUFACTURING INDONESIA</h3></td>
        </table>
    </div>

    <div class="content">
      <iframe src="" name="iframetarget" frameborder="0" width="100%" height="100%">SELAMAT DATANG <a href="tambah-user.php">Tambah User</a></iframe>
    </div>
    </div>

    <script>
      function logout() {
        // Konfirmasi sebelum logout
        var konfirmasi = confirm('Apakah Anda yakin ingin logout?');
        if (konfirmasi) {

          sessionStorage.removeItem('loggedIn');
    
          window.location.href = 'login.php';
        }
      }
    </script>

</body>
</html>