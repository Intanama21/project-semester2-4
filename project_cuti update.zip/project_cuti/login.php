<style>
body {
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  margin: 0;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
}

table {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
}

form {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
}

input {
  width: 100%;
  padding: 10px;
  box-sizing: border-box;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

input[type="submit"] {
  background-color: #4caf11;
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"] :hover {
  background-color: #45a049;
}

img {
    display: block;
    margin: auto;
    margin-bottom: 20px; 
    width: 200px;
}
    </style>
<?php
 echo"
  <form action=periksa.php method=post>
  <h2>LOGIN</h2>
  <table>
  <tr>
  <td><input type=text name=id_user placeholder=' Masukkan NIK '></td></tr>
  <tr>
  <td><input type=password name=sandi placeholder='Kata sandi'></td></tr>
  <tr>
  <td><input type=submit value=Login></tr>
  <tr><td>Belum punya akun? <a href=tambah-user.php>Daftar</a>

  </table>
  <br>
  <img src='logo-pt.png' alt='Logo' width='100'>
 </form>";
 
?>
