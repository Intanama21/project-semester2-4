<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}

//Pencarian
include "koneksi.php";
$query = "SELECT * FROM persetujuan_cuti";


if(isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
   
    $query .= " WHERE nama LIKE '%$keyword%' 
    OR departemen LIKE '%$keyword%' OR status_cuti LIKE '%$keyword%'";
}

$query .= " ORDER BY nik ASC";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Error: " . mysqli_error($koneksi));
}

?>
<head>
 <style>

  table{
      border: 0px;
      float: left;
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th{
      background-color: orange;
      text-align: center;
    }

    td, th{
      border: 1px solid #ddd;
      padding: 8px;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
      background-color: #ffffff;
    }

    tr:nth-child(odd):hover, tr:nth-child(even):hover{
      background-color: orange;}
 </style>
</head>

<body>
<h2 align = "center">DATA CUTI</h2>
<form method="GET" action="cuti.php">
    <input type="text" name="cari" placeholder="Cari berdasarkan nama atau departemen"  size="100px">
    <button type="submit">Cari</button>
</form>
		
	<table border=1>
		<tr>
        <th>No</th> 
		    <th>ID Persetujuan</th>
        <th>NIK</th>
        <th>Nama</th>
        <th>Departemen</th>
        <th>Tanggal Mulai</th>
        <th>Tanggal Selesai</th>
        <th>Jenis Cuti</th>
        <th>Status</th>
        <th>Catatan</th>
		</tr>

    <?php
        $no = 1;
        while ($tampil = mysqli_fetch_assoc($result)) {
        ?>
            <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $tampil['id_persetujuan']; ?></td>
                <td><?php echo $tampil['nik']; ?></td>
                <td width="100"><?php echo $tampil['nama']; ?></td>
                <td width="100"><?php echo $tampil['departemen']; ?></td>
                <td><?php echo $tampil['tgl_mulai']; ?></td>
                <td><?php echo $tampil['tgl_selesai']; ?></td>
                <td><?php echo $tampil['jenis_cuti']; ?></td>
                <td><?php echo $tampil['status_cuti']; ?></td>
                <td><?php echo $tampil['catatan']; ?></td>
            </tr>
                
            <?php
            $no++;
        }
        ?>
    </table>
      </body>
