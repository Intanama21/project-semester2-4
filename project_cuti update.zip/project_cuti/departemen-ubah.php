<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";
if (isset($_GET['kode'])) {
$sql = mysqli_query($koneksi, "SELECT * FROM departemen where kode_departemen='$_GET[kode]'");
$data=mysqli_fetch_array($sql);
}
?>
<h3>Ubah Data Departemen</h3>
<form action="" method="POST">
    <table>
        <tr>
            <td width="120">Kode Departemen</td>
            <td> <input type="text" name="kode_departemen" value="<?php echo $data['kode_departemen'];?>"></td>
</tr>
<tr>
            <td>Nama Departemen</td>
        <td> <select name="departemen" value="<?php echo $data['nama_departemen'];?>">
            <option value="">--pilih-- </option>
            <option value="HRGA">HR-GA</option>
            <option value="Accounting">Accounting</option>
            <option value="QA/QC">QA/QC</option>
            <option value="Produksi">Produksi</option>
            <option value="PPIC">PPIC</option>
            <option value="Marketing">Marketing</option>
            <option value="STII">STII</option>
            </select></td>
</tr>

<tr>
    <td>Nama Divisi</td>
    <td> <input type="text" name="divisi" value="<?php echo $data['nama_divisi'];?>"></td>
</tr>

<tr>
    <td>Jabatan</td>
    <td> <input type="text" name="jabatan" value="<?php echo $data['jabatan'];?>"></td>
</tr>
<tr>
    <td>Jumlah Karyawan</td>
    <td> <input type="text" name="karyawan" value="<?php echo $data['jumlah_karyawan'];?>"></td>
</tr>
<tr>
    <td></td>
    <td> <input type="submit" value="Ubah data" name="ubah"></td>
</tr>
</table>
</form>
<?php
if(isset($_POST['ubah'])){
    mysqli_query($connect, "UPDATE departemen SET
    kode_departemen = '$_POST[kode_departemen]',
    nama_departemen = '$_POST[nama_departemen]',
    nama = '$_POST[nama_divisi]',
    jabatan = '$_POST[jabatan]',
    jumlah_karyawan = '$_POST[jumlah_karyawan]', WHERE kode='$_GET[kode]'");
    echo "<script>alert('Data berhasil diubah'); window.location='data_departemen.php'</script>";
}
?>