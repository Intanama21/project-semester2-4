<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}

    ?> <br><br>
    
    <!DOCTYPE html>
<html>
<head>
    <title>FORM DATA KARYAWAN</title>
    <style>
    body, h3, table {
        margin: 0;
        padding: 0;
        }

        h3 {
            text-align: center;
        }

        form {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        font-family: arial:
        }

        table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        border : 0;
        }


        th {
        background-color: #f2f2f2;
        padding: 10px;
        text-align: left;
        }

        td {
        border: 0px solid #ddd;
        padding: 10px;
        }


        input, a {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
        }

       /* Gaya Tombol */
a.tombol-link {
    align-items: center;
    display: inline-block;
    background-color:orange;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
    border: none;
    cursor: pointer;
}

a.tombol-link:hover {
    background-color: orange;
    text-align: center;
}

        
        </style>
</head>
<body>
    <form action="simpan_karyawan.php"  method="POST" onSubmit="return validasi()" class="Tabel" border="1">
        <table>
            <th colspan="50"><h3>FORM DATA KARYAWAN</h3></th>
            <tr>
                <td>NIK</td><td>:</td>
                <td><input type="text" name="nik" id="nik" size="30" maxlength="15"></td>
            </tr>
            <tr>
                <td>Nama</td><td>:</td>
                <td><input type="text" name="nama" id="nama" size="30" maxlength="50"></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td><td>:</td>
                <td><input type="date" name="tgl_lahir" id="tgl_lahir" size="30" ></td>
</tr>
            <tr>
                <td>Departemen</td><td>:</td>
                <td> 
                    <select name="departemen" id="departemen">
                    <option value="">--pilih-- </option>
                    <option value="HRGA">HR-GA</option>
                    <option value="accounting">Accounting</option>
                    <option value="qa/qc">QA/QC</option>
                    <option value="produksi">Produksi</option>
                    <option value="ppic">PPIC</option>
                    <option value="marketing">Marketing</option>
                    <option value="stii">STII</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Alamat</td><td>:</td>
                <td><textarea cols="30" rows="5" name="alamat" id="alamat"></textarea></td>
            </tr>
            <tr>
                <td>No.HP</td><td>:</td>
                <td><input type="text" name="no_hp" id="no_hp" size="30"></td>
            </tr>
            <tr>
                <td>Tanggal Masuk</td><td>:</td>
                <td><input type="date" name="tgl_masuk" id="tgl_masuk" /></td>
            </tr>
           
            <tr>
                <td colspan="3">
                    <input type="submit" name="proses" value="Simpan" class="tombol">
                    <a href= tampil_karyawan.php class="tombol-link">Lihat Data Karyawan</a>
                </td>
            </tr>
        </table>
    </form>
    <script type="text/javascript">
        function validasi() {
            var nik = document.getElementById("nik").value;
            var nama = document.getElementById("nama").value;
            var tgl_lahir = document.getElementById("tgl_lahir").value;
            var departemen = document.getElementById("departemen").value;
            var alamat = document.getElementById("alamat").value;
            var no_hp = document.getElementById("no_hp").value;
            var tgl_masuk = document.getElementById("tgl_masuk").value;
            
            if (nik !== "" && nama !== "" && tgl_lahir !== "" && departemen !== "" && alamat !== "" && no_hp !== "" && tgl_masuk !== "") {
                return true;
            } else {
                alert('Anda harus mengisi data dengan lengkap!');
                return false;
            }
        }
    </script>
 
</body>
    </html>