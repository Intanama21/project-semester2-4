<?php
 if(!isset($_SESSION['id']))
 {
	 echo "<script>
		 alert('Silakan login dahulu');		
		 window.location = 'login.php'; 
		</script>";
	 exit;	
 }
?>
