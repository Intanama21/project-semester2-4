
<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = 'login.php'; 
       </script>";
    exit;	
}
?>

<html>
    <p>Selamat Datang!</p>
</html>