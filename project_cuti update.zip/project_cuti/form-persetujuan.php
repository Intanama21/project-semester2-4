<head>
    <style>
        body, h3, table {
        margin: 0;
        padding: 0;
        }

        form {
        max-width: 600px;
        margin: 10px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        font-family: :  system-ui, apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        label {
            text-align: left;
        }

        table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 5px;
        border : 0;
        }
        select#departemen {
            width: 600px;
            background-color: none;
        
        }


        th {
        background-color: #f2f2f2;
        padding: 10px;
        text-align: none;
        font-family: Helvetica;
        }

        td {
        border: 0px solid #ddd;
        padding: 10px;
        
        }


        input, select {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
        }

        input[type="submit"] {
        background-color: orange;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        }

        input[type="submit"]:hover {
        background-color:#181717;
        }

    </style>
</head>
<body>

    <form action="form-persetujuan.php" method="post">

    <h3 align="center">PERSETUJUAN CUTI</h3>
    <table>
    <tr><td><label for="id_persetujuan">ID Persetujuan</label></td></tr>
    <tr><td><input type="text" name="id_persetujuan"></td></tr>
    <tr><td><label>NIK</label></td></tr><tr>
    <tr><td><input type="text" name="nik"></td></tr>
    <tr><td><label for="nama">Nama Lengkap</label></td></tr>
    <tr><td><input type="text" name="nama"></td></tr>
    <tr><td><label for="departemen">Departemen</label></td></tr>
    <tr>
                <td>
                    <select name="departemen" id="departemen" size="1px" >
                        <option value="Accounting">Accounting</option>
                        <option value="HR-GA">HR-GA</option>
                        <option value="Production">Production</option>
                        <option value="Forging">Forging</option>
                        <option value="PD01-Press">PD01-Press</option>
                        <option value="PD01-T.R">PD01-T.R</option>
                        <option value="PD01-F/I">PD01-F/I</option>
                        <option value="PD01-H/T">PD01-H/T</option>
                        <option value="PD02-Plating">PD02-Plating</option>
                        <option value="Sales">Sales</option>
                        <option value="STII">STII</option>
                    </select>
                </td>
            </tr>
    <tr><td><label for="tgl_mulai">Tanggal Mulai</label></td></tr>
    <tr><td><input type="date" name="tgl_mulai"></td></tr>
    <tr><td><label for="tgl_selesai">Tanggal Selesai</label></td></tr>
    <tr><td><input type="date" name="tgl_selesai"></td></tr>
    <tr><td><label for="jenis_cuti">Jenis Cuti</label></td></tr>
    <tr><td><select name="jenis_cuti" id="jenis_cuti">
        <option value="Cuti Tahunan">Cuti Tahunan</option>
        <option value="Cuti Khusus">Cuti Khusus</option>
    </select></td></tr>
    <tr>
        <td>Disetujui<input type="radio" name="status_cuti" value="disetujui"></td> <br>
    </tr>
    <tr>
    <td>Ditolak<input type="radio" name="status_cuti" value="ditolak"></td>
    </tr>
    <tr><td><label for="catatan">Catatan</label></td></tr>
    <tr>
        <td><textarea name="catatan" id="catatan" cols="76" rows="5"></textarea></td>
    <tr>
        <td><input type="submit" name="save" value="Simpan" ></td>
       
    </tr>
    </table>
    </form>

<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
	include "koneksi.php";
	
	if(isset($_POST['save'])){

		mysqli_query($koneksi,"INSERT INTO persetujuan_cuti SET
        
        id_persetujuan = '$_POST[id_persetujuan]',
        nik  = '$_POST[nik]',
        nama  = '$_POST[nama]',
        departemen  = '$_POST[departemen]',
        tgl_mulai  = '$_POST[tgl_mulai]',
        tgl_selesai  = '$_POST[tgl_selesai]',
        jenis_cuti = '$_POST[jenis_cuti]',
        status_cuti  = '$_POST[status_cuti]',
        catatan = '$_POST[catatan]';
        ");

			echo "<script>
            alert('Data Berhasil Disimpan');
            window.location = 'pengajuan-cuti.php';
           </script>";
    }
?>



