<!DOCTYPE html>
<html>
<head>
    <title>Tambah User</title>
    <style>
        /* CSS untuk mengatur tampilan formulir */
        table {
            border-collapse: collapse;
            width: 50%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 6px 10px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"],
        input[type="reset"] {
            width: auto;
            background-color: #4CAF50;
            color: white;
            padding: 10px 18px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Isi formulir Anda di sini -->
</body>
</html>

<h3 align="center">TAMBAH USER</h3>
        <form action=""  method="POST">
        <table align="center">
        <tr>
            <td>NIK</td>
            <td> <input type="text" name="nik" size="20"></td>
        </tr>
  
            <tr>
                <td width="150">Nama Lengkap</td>
                <td><input type="text" name="nama"size=20></td>
            </tr>
            <tr>
           <td>Jabatan</td>
            <td><input type="text" name="jabatan"size=20></td>
            </tr>
            <tr>
            <td>Nama Departemen</td>
        <td> <select name="departemen">
            <option value="">--pilih-- </option>
            <option value="HRGA">HR-GA</option>
            <option value="Accounting">Accounting</option>
            <option value="QA/QC">QA/QC</option>
            <option value="Produksi">Produksi</option>
            <option value="PPIC">PPIC</option>
            <option value="Marketing">Marketing</option>
            <option value="STII">STII</option>
            </select></td>
</tr>
<tr>
    <td>Nama Divisi</td>
    <td> <input type="text" name="divisi"></td>
<tr>
        <tr>
            <td>Level Akses</td>
          <td><select name="level">
            <option>---</option>    
            <option value="hr_ga">HR-GA</option>
            <option value="supervisor">Supervisor</option>
            <option value="Manager">Manager</option>
            <option value="operator">Operator</option>
        </tr>
        <td>Kata Sandi</td>
        <td><input type="password" name="sandi2"size=20></td>
        </tr>
        <tr>
            <td>Ulangi Kata Sandi</td>
        <td><input type="password" name="ulang"size=20></td>
        </tr>
            <tr>
            <td> <input type="submit" name="simpan"value="simpan"> </td>
            <td> <input type="reset" name="reset"value="Reset"> </td>
        </tr>
        </table>
        </form>
    <?php
            include "koneksi.php";
            if(isset($_POST['simpan'])){
    
    mysqli_query($koneksi,  "INSERT INTO user SET
    nik = '$_POST[nik]',
    nama_lengkap = '$_POST[nama]',
    jabatan = '$_POST[jabatan]',
    departemen = '$_POST[departemen]',
    divisi = '$_POST[divisi]',
    level_akses = '$_POST[level]',
    kata_sandi= '$_POST[sandi2]',
    ulangi_kata_sandi= '$_POST[ulang]'");

    echo "Data telah tersimpan";
    
}
?> 
