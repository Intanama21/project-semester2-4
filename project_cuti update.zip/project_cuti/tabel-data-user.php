<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: orange;
            text-align:center;
        }

        tr:nth-child(even) {
            background-color: white;
        }

        tr:hover {
            background-color: white;
        }

        tr:nth-child(odd):hover, tr:nth-child(even):hover{
      background-color: orange;}
        a {
            text-decoration: none;
            padding: 2px 6px;
            border: 1px solid #ccc;
            border-radius: 3px;
            background-color: #f2f2f2;
        }

        a:hover {
            background-color: #e2e2e2;
        }
    </style>
</head>
<body>
<h2 align="center">DATA USER</h2>

<table border='1'>
    <tr>
    <th>ID User</th>
    <th>Nama Email</th>
    <th>Kata Sandi</th>
    <th>Grup</th>
    <th colspan="2">Aksi</th>
 </tr>
</body>
<?php
include "koneksi.php";
$sql = mysqli_query($koneksi, "SELECT  * FROM user");
while($tampil = mysqli_fetch_array($sql)){
echo"
<tr>
<td>$tampil[id_user]</td>
<td>$tampil[nama_email]</td>
<td>$tampil[sandi]</td>
<td>$tampil[grup]</td>
<td> <a href='?id=$tampil[id]'>Hapus</a></td>
<td> <a href='ubah-data_user.php?id=$tampil[id]'>Ubah</a></td>
</tr>";
}
?>
</table>
<?php
include "koneksi.php";

if(isset($_GET['id_user'])){
    mysqli_query($koneksi, "DELETE FROM user where id_user='$_GET[id_user]'");
echo "Data telah terhapus";
}
?>

