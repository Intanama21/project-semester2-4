<?php
	session_start();
		$koneksi = mysqli_connect("localhost","root","","db_cuti");
		$id_user 	= $_POST['id_user'];
		$sandi 	= $_POST['sandi'];
		
		//cek kiriman
		//echo $id."-".$sandi;
		
		//Periksa id pengguna di DB
		
		$cek = mysqli_query($koneksi,"select * from user where id_user='$id_user'");
		$jbaris = mysqli_num_rows($cek);
		
		//echo $jbaris;
		
		if($jbaris==0)
		{
			echo "<script>
			 alert('Id belum terdaftar');
			 window.location = 'login.php';
			</script>";
		}
		else
		{
			//periksa kata sandi
			$cek_sandi = mysqli_query($koneksi,"select * from user where id_user='$id_user' and sandi='$sandi'");
			$jbaris_sandi = mysqli_num_rows($cek_sandi);
			if($jbaris_sandi==0)
			{
			echo "<script>
			 alert('Kata sandi salah');
			 window.location = 'login.php';
			</script>";
			}
			else
			{
				//mengambil id dan nama yang aktif
			$q = mysqli_query($koneksi,"select * from user where id_user='$id_user'");
			$data = mysqli_fetch_array($q);
			//membuat sesi/SESSION
			
			$_SESSION['id_user'] = $data['id_user'];
			$_SESSION['sandi'] = $data['sandi'];
			
			if($data['grup'] == 'Karyawan')
			{
				header("Location: halaman-karyawan.php");
			}
			else
			if($data['grup'] == 'Admin')
			{
				header("Location: halaman-utama.php");
			}
				
			}
		}
		
	
	?>



