<!DOCTYPE html>
<html>
<head>
    <style>
        /* Gaya CSS Anda di sini */
    </style>
</head>
<body>
    <?php
    include "koneksi.php";

    if(isset($_GET['id_user'])) {
        $id = $_GET['id_user'];
        $query = mysqli_query($koneksi, "SELECT * FROM user WHERE id_user = '$id'");
        $data = mysqli_fetch_array($query);
    ?>

    <h2 align="center">UBAH DATA USER</h2>
    <form method="POST" action="ubah-user.php">
        <input type="hidden" name="id_user" value="<?php echo $data['id_user']; ?>">
        <table border='1'>
            <tr>
                <td>ID User</td>
                <td><input type="text" name="id_user" value="<?php echo $data['id_user']; ?>" readonly></td>
            </tr>
            <tr>
                <td>Nama Email</td>
                <td><input type="text" name="nama_email" value="<?php echo $data['nama_email']; ?>"></td>
            </tr>
            <tr>
                <td>Kata Sandi</td>
                <td><input type="password" name="sandi" value="<?php echo $data['sandi']; ?>"></td>
            </tr>
            <tr>
            <td>Masuk Sebagai</td>
            <td>
                <select name="grup">
                    <option value="Admin" <?php echo ($data['grup'] == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                    <option value="Karyawan" <?php echo ($data['grup'] == 'Karyawan') ? 'selected' : ''; ?>>Karyawan</option>
                </select>
            </td>
        </tr>

            <tr>
                <td colspan="2" align="center">
                    <input type="submit" value="Simpan Perubahan">
                </td>
            </tr>
        </table>
    </form>
    <?php
    echo "<script>
        alert('Data Berhasil Di ubah');
        window.location = 'tabel-data-user.php' 
        </script>"
    ?>

    <?php } ?>
</body>
</html>
