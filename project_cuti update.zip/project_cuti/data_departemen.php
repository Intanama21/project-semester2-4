<!DOCTYPE html>
<html>
<head>
    <title>Departemen</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
           
        }

        th {
            background-color: orange;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: white;
        }

        tr:hover {
            background-color: white;
        }

        tr:nth-child(odd):hover, tr:nth-child(even):hover{
      background-color: orange;}
        a {
            text-decoration: none;
            padding: 2px 6px;
            border: 1px solid #ccc;
            border-radius: 3px;
            background-color: #f2f2f2;
        }

        a:hover {
            background-color: #e2e2e2;
        }
    </style>
</head>
<body>
    <h2 align="center">DATA DEPARTEMEN</h2>

    <form action="" method="GET">
        <input type="text" id="search_query" name="search_query" placeholder="Cari berdaasarkan nama atau departemen" size="100">
        <input type="submit" value="Cari">
    </form>

    <table border='1'>
        <tr>
            <th>Kode Departemen</th>
            <th>Nama Departemen</th>
            <th>Nama Divisi</th>
            <th>Jabatan</th>
            <th>Jumlah Karyawan</th>
            <th colspan="2">Aksi</th>
        </tr>
        
        <?php
        include "koneksi.php";
        session_start();
        if(!isset($_SESSION['id_user']))
        {
            echo "<script>
                alert('Silakan login dahulu');		
                window.location = '../project_cuti/login.php'; 
               </script>";
            exit;	
        }
        
        // Logika pencarian
        $condition = "";
        if(isset($_GET['search_query'])) {
            $search = $_GET['search_query'];
            $condition = " WHERE nama_departemen LIKE '%$search%' OR nama_divisi LIKE '%$search%' OR jabatan LIKE '%$search%'";
        }
        ?>

        <br>
        <?php

        $sql = mysqli_query($koneksi, "SELECT * FROM departemen $condition");
        while($tampil = mysqli_fetch_array($sql)){
            echo "
            <tr>
                <td>$tampil[kode_departemen]</td>
                <td>$tampil[nama_departemen]</td>
                <td>$tampil[nama_divisi]</td>
                <td>$tampil[jabatan]</td>
                <td>$tampil[jumlah_karyawan]</td>
                <td><a href='?kode=$tampil[kode_departemen]'>Hapus</a></td>
                <td><a href='departemen-ubah.php?kode=$tampil[kode_departemen]'>Ubah</a></td>
            </tr>";
        }
        ?>
    </table>
    
    <?php
    if(isset($_GET['kode'])){
        mysqli_query($koneksi, "DELETE FROM departemen WHERE kode_departemen='$_GET[kode]'");
        echo "Data telah terhapus";
    }
    ?>
</body>
</html>
