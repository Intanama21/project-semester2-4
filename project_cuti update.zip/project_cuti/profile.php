<h3>Profile</h3>
        <form action="" method="POST">
        <table>
            <tr>
                <td width="150"> Username </td>
                <td><input type="text" name="user"size=20></td>
            </tr>
            <tr>
           <td>NIK</td>
            <td><input type="text" name="nik"size=20></td>
            </tr>
            <tr>
                <td>Nama</td>
            <td><input type="text" name="nama"size=20></td>
            </tr>
            <tr>
                <td>Jabatan</td>
            <td><input type="text" name="jabatan"size=20></td>
            </tr>
            <tr>
            <td>Nama Departemen</td>
        <td> <select name="departemen">
            <option value="">--pilih-- </option>
            <option value="HRGA">HR-GA</option>
            <option value="Accounting">Accounting</option>
            <option value="QA/QC">QA/QC</option>
            <option value="Produksi">Produksi</option>
            <option value="PPIC">PPIC</option>
            <option value="Marketing">Marketing</option>
            </select></td>
        </tr>
        <tr>
            <td>Divisi<td>
                <input type="text" name="divisi"></td>
        </tr>
            <tr>
            <td> <input type="submit" name="simpan"value="simpan perubahan"> </td>
           
        </tr>
        </table>
        </form>
        <?php
include "koneksi.php";
if(isset($_POST['simpan'])){
    
    mysqli_query($koneksi,  "INSERT INTO profil SET
    username = '$_POST[user]',
    nik = '$_POST[nik]',
    nama = '$_POST[nama]',
    jabatan = '$_POST[jabatan]',
    departemen = '$_POST[departemen]',
    divisi = '$_POST[divisi]'");

    echo "Data telah tersimpan";
    
}
?>