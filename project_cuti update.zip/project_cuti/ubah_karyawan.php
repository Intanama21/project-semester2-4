  <?php
include 'koneksi.php';


function getKaryawanByNIK($nik) {
    global $koneksi; 

    $query = "SELECT * FROM karyawan WHERE nik = '$nik'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Error: " . mysqli_error($koneksi));
    }

    $karyawanData = mysqli_fetch_assoc($result);
    return $karyawanData;
}


function updateKaryawan($nik, $newKaryawanData) {
    global $koneksi; 

    $query = "UPDATE karyawan SET nama = '$newKaryawanData[nama]', tgl_lahir = '$newKaryawanData[tgl_lahir]',
     departemen = '$newKaryawanData[departemen]', no_hp = '$newKaryawanData[no_hp]', tgl_masuk = '$newKaryawanData[tgl_masuk]'
      WHERE nik = '$nik'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Error: " . mysqli_error($koneksi));
    }
}


if (isset($_GET['nik'])) {
    $nik = $_GET['nik'];
    $karyawanData = getKaryawanByNIK($nik);

    if (!$karyawanData) {
        echo "Data karyawan tidak ditemukan.";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newKaryawanData = [
            'nama' => $_POST['nama'],
            'tgl_lahir' => $_POST['tgl_lahir'],
            'departemen' => $_POST['departemen'],
            'no_hp' => $_POST['no_hp'],
            'tgl_masuk' => $_POST['tgl_masuk']
        ];

        updateKaryawan($nik, $newKaryawanData);

       
        header('Location: tampil_karyawan.php');
        exit;
    }
} else {

    echo "NIK karyawan tidak ditemukan.";
    exit;
}
?>  



    <!DOCTYPE html>
<html>
<head>
    <title>Form Ubah Data Karyawan</title>
    <style>
    body {
            font-family: Arial, sans-serif;
        }
        form {
            max-width: 455px;
            margin: 0 auto;
        }
        label {
            display: inline-block;
            width: 100px; /* Adjust width as needed */
            text-align: right;
            margin-right: 100px;
        }
        input,
        select {
            display: inline-block;
            width: 250px; /* Adjust width considering label width and margin */
            margin-bottom: 5px;
        }
        input[type="submit"] {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: ;
            color: black;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: orange;
        }
    </style>
</head>
<body>
    <h1 align="center">Ubah Data Karyawan</h1>
    <form method="POST" align="center" action="">
        <tr>
            <td>Nama :</td>
        <input type="text" name="nama" placeholder="Nama"  value="<?php echo $karyawanData['nama']; ?>" required><br>
             <td>Tanggal Lahir :</td>
        <input type="date" name="tgl_lahir" value="<?php echo $karyawanData['tgl_lahir']; ?>" required><br>
        
        <label for="departemen">Department:</label>
            <select name="departemen"  id="departemen" required>
                <?php
                $departemen = [
                    "Accounting",
                    "HR-GA",
                    "Production",
                    "Forging",
                    "PD01-Press",
                    "PD01-T.R",
                    "PD01-F/I",
                    "PD01-H/T",
                    "PD02-Plating",
                    "Sales",
                    "STII"
                ];

                foreach ($departemen as $dept) {
                    $selected = ($karyawanData['departemen'] == $dept) ? 'selected' : '';
                    echo "<option value='$dept' $selected>$dept</option>";
                }
                ?>
            </select>
      <br>
        <td>No Hp :</td>
        <input type="text" name="no_hp" placeholder="Nomor HP"  value="<?php echo $karyawanData['no_hp']; ?>" required><br>
        <td>Tanggal Masuk :</td>
        <input type="date" name="tgl_masuk" size="50px" value="<?php echo $karyawanData['tgl_masuk']; ?>" required><br>
        <input type="submit" value="Simpan">
    </form>
</tr>
<script>
    function Simpan() {
        window.location.replace("tampil_karyawan.php");
    }
</script>

</body>
</html>


<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (updateKaryawan($nik, $newKaryawanData)) {
        echo "Data berhasil diubah.";
        header('refresh:2; url=tampil_karyawan.php'); 
        exit;
    } else {
        echo "Gagal mengubah data.";
    }
}


?>
