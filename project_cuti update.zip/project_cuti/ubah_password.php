<h3>Ubah Password</h3>
        <form action="" method="POST">
        <table>
            <tr>
                <td width="150">Password Lama</td>
                <td><input type="password" name="sandi1"size=20></td>
            </tr>
           <td>Password Baru</td>
            <td><input type="password" name="sandi2"size=20></td>
            </tr>
            <tr>
                <td>Ulangi Password</td>
            <td><input type="password" name="ulang"size=20></td>
            </tr> <tr>
           
           <tr></tr>
            <td> <input type="submit" name="ubah" value="Simpan"> </td>
            
        </tr>
        </table>
        </form>
        <?php
include "koneksi.php";

if(isset($_POST['ubah'])){
    $password_lama = $_POST['sandi1'];
    $password_baru = $_POST['sandi2'];
    $ulangi_password = $_POST['ulang'];

    // Lakukan verifikasi kata sandi lama 
    
    // Jika kata sandi baru cocok dengan ulangi kata sandi
    if ($password_baru === $ulangi_password) {
        // Menggunakan MD5 untuk menghash password baru sebelum disimpan
        $hashed_password = md5($password_baru);

        // Simpan password baru yang di-hash ke database, sesuaikan dengan struktur tabel Anda
        mysqli_query($connect, "UPDATE ubah_password SET kata_sandi = '$hashed_password' WHERE kondisi_update");
        
        echo "Password berhasil diubah";
    } else {
        echo "Kata sandi baru dan ulang kata sandi tidak cocok";
    }
}
?>
