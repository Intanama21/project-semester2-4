<head>
    <style>
        table, tr, th {
            border-collapse: collapse;
            border: 1;
            width: 100%;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
         /* Gaya baris genap */
    tr:nth-child(odd) {
      background-color:  #ffffff ;
    }

    /* Gaya baris ganjil */
    tr:nth-child(even) {
      background-color: #ffffff;
    }

     form {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 500px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            size: 100%;
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: orange;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: yellow;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
    <h3 align="center">PENGAJUAN CUTI</h3>
    <br>
    <table>
    <tr><td><label for="id_persetujuan">ID Pengajuan</label></td></tr>
    <tr><td><input type="text" name="id_pengajuan"></td></tr>
    <tr><td><label>NIK</label></td></tr><tr>
    <tr><td><input type="text" name="nik"></td></tr>
    <tr><td><label for="nama">Nama</label></td></tr>
    <tr><td><input type="text" name="nama"></td></tr>
    <tr><td><label for="departemen">Departemen</label></td></tr>
    <tr><td><input type="text" name="departemen"></td></tr>
    <tr><td><label for="tgl_mulai">Tanggal Mulai</label></td></tr>
    <tr><td><input type="date" name="tgl_mulai"></td></tr>
    <tr><td><label for="tgl_selesai">Tanggal Selesai</label></td></tr>
    <tr><td><input type="date" name="tgl_selesai"></td></tr>
    <tr>
    <tr><td><label for="jenis_cuti">Jenis Cuti</label></td></tr>
    <td>
                    <select name="jenis_cuti" required>
                        <option value="Cuti Tahunan">Cuti Tahunan</option>
                        <option value="Cuti Khusus">Cuti Khusus</option>
    </td>
                    </select>
        <tr></tr>
    </tr>
    <tr><td><label for="alasan">Alasan</label></td></tr>
    <tr><td><input type="text" name="alasan"></td></tr>
    <tr>
        <td><input type="submit" name="save" value="Kirim" ></td>
    </tr>
    </table>
    </form>

<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
	include "koneksi.php";
	
	if(isset($_POST['save'])){

		mysqli_query($koneksi,"INSERT INTO pengajuan_cuti SET
        
        id_pengajuan = '$_POST[id_pengajuan]',
        nik  = '$_POST[nik]',
        nama  = '$_POST[nama]',
        departemen  = '$_POST[departemen]',
        tgl_mulai  = '$_POST[tgl_mulai]',
        tgl_selesai  = '$_POST[tgl_selesai]',
        jenis_cuti = '$_POST[jenis_cuti]',
        alasan = '$_POST[alasan]';
        ");

    }
   
?>



