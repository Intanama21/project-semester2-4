<?php
session_start();
if(!isset($_SESSION['id']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";

if(isset($_POST['proses'])) 
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $departemen = $_POST['departemen'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];
    $tgl_masuk = $_POST['tgl_masuk'];

   
    $query = "INSERT INTO karyawan (nik, nama, tgl_lahir, departemen, alamat, no_hp, tgl_masuk)
              VALUES ('$nik', '$nama', '$tgl_lahir', '$departemen', '$alamat', '$no_hp', '$tgl_masuk')";


    $result = mysqli_query($koneksi, $query);

    
        echo "<script>
        alert('Data Berhasil Disimpan');
        window.location = 'tampil_karyawan.php' 
        </script>"

    
?> 

