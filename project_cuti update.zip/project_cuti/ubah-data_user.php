<!DOCTYPE html>
<html>
<head>
    <title>Tambah User</title>
    <style>
        /* CSS untuk mengatur tampilan formulir */
        table {
            border-collapse: collapse;
            width: 50%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 6px 10px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"],
        input[type="reset"] {
            width: auto;
            background-color: #4CAF50;
            color: white;
            padding: 10px 18px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<?php
include "koneksi.php";
$sql = mysqli_query($koneksi, "SELECT * FROM user where id_user='$_GET[id]'");
$tampil = mysqli_fetch_array($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ubah Data User</title>
    <!-- CSS dan tag <style> bisa ditambahkan di sini -->
</head>
<body>
    <h2 align="center">UBAH DATA USER</h2>
    <form action="" method="POST">
        <table>
            <tr>
                <td width="120"> ID User</td>
                <td> <input type="text" name="id_user" value="<?php echo $tampil['id_user']; ?>"></td>
            </tr>
            <tr>
                <td>Nama Email</td>
                <td> <input type="email" name="nama_email" value="<?php echo $tampil['nama_email']; ?>"></td>
            </tr>
            <tr>
                <td>Kata Sandi</td>
                <td> <input type="password" name="sandi" value="<?php echo $tampil['sandi']; ?>"></td>
            </tr>
            <tr>
                <td>Masuk Sebagai</td>
                <td>
                    <select name="grup">
                        <option value="Admin" <?php echo ($data['grup'] == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                        <option value="Karyawan" <?php echo ($data['grup'] == 'Karyawan') ? 'selected' : ''; ?>>Karyawan</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td> <input type="submit" name="ubah" value="ubah"></td>
            </tr>
        </table>
    </form>

    <?php
    if (isset($_POST['ubah'])) {
        mysqli_query($koneksi, "UPDATE user SET
        id_user = '$_POST[id_user]',
        nama_email = '$_POST[nama_email]',
        sandi = '$_POST[sandi]',
        grup = '$_POST[grup]'
        WHERE id_user='$_GET[id]'");

        echo "<script>alert('Data berhasil diubah'); window.location='tabel-data-user.php?id=$_GET[id]'</script>";
    }
    ?>
</body>
</html>
