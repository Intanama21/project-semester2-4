<?php
session_start();
if(!isset($_SESSION['id']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";

if(isset($_GET['id'])){
    mysqli_query($koneksi, "DELETE FROM user where id='$_GET[id]'");
echo "Data telah terhapus";


echo "<script>alert('Data berhasil dihapus'); window.location='tabel-data-user.php?id=$_GET[id]'</script>";
}
?>




