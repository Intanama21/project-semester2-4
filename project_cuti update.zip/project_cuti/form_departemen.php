<style>
    table {
        border-collapse: collapse;
        width: 50%;
        margin: 20px auto;
    }
    
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
    
    th {
        background-color: #f2f2f2;
    }
    
    input[type="text"], select {
        width: 100%;
        padding: 5px;
        box-sizing: border-box;
    }
    
    input[type="submit"], input[type="reset"] {
        padding: 8px 16px;
        margin-top: 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    
    input[type="submit"]:hover{
        background-color: #45a049;
    }
</style>

<h2 text align="center">FORM DEPARTEMEN</h2>
    <form action="" method="POST">
        <table>
<tr>
            <td width="150">Kode Departemen</td>
            <td> <input type="text" name="kode"> </td>
</tr>
<tr>
            <td>Nama Departemen</td>
        <td> <select name="departemen">
            <option value="">--pilih-- </option>
            <option value="HRGA">HR-GA</option>
            <option value="accounting">Accounting</option>
            <option value="qa/qc">QA/QC</option>
            <option value="produksi">Produksi</option>
            <option value="ppic">PPIC</option>
            <option value="marketing">Marketing</option>
            <option value="stii">STII</option>
            </select></td>
</tr>
<tr>
    <td>Nama Divisi</td>
    <td> <input type="text" name="divisi"></td>
<tr>
            <td>Jabatan</td>
            
            <td> <input type="text" name="jabatan" ></td>
</tr>
<tr>
            <td>Jumlah Karyawan</td>
            <td> <input type="text" name="jumlah" ></td>
</tr>
<tr>
    <td>
<input type="submit" name="save" value="simpan"></td>
</tr>
</tr>
</table>
</form>
<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";
if(isset($_POST['save'])){
    mysqli_query($koneksi,  "INSERT INTO departemen SET
    kode_departemen = '$_POST[kode]',
    nama_departemen = '$_POST[departemen]',
    nama_divisi = '$_POST[divisi]',
    jabatan = '$_POST[jabatan]',
    jumlah_karyawan = '$_POST[jumlah]'");

    echo "Data telah tersimpan";
    
}
?>