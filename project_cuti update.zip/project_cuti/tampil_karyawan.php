<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";
$query = "SELECT * FROM karyawan";


if(isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
   
    $query .= " WHERE nama LIKE '%$keyword%' 
    OR departemen LIKE '%$keyword%' OR alamat LIKE '%$keyword%'";
}

$query .= " ORDER BY nik ASC";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Karyawan</title>
    <style>
        table {
            border-collapse: collapse;
            width: 950px;
            margin: 10px auto;
            align: center;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: rgba(255,228,181);
        }
        td {
            background-color: rgba(255,255,290);
        }
    
    </style>
</head>
<body>
    <h2 align="center">DATA KARYAWAN</h2>
    <form method="GET" action="tampil_karyawan.php">
        <input type="text" name="cari" placeholder="Cari berdasarkan nama, departemen, atau alamat"  size="100px">
        <button type="submit">Cari</button>
    <a href="form_karyawan.php" >Tambah Data</a>
    </form>
    <table border="1" align="center" width="800">
        <tr>
            <th> NO </th>
            <th> NIK </th>
            <th> Nama </th>
            <th> Tanggal Lahir </th>
            <th> Department </th>
            <th> Alamat </th>
            <th> No HP </th>
            <th> Tanggal Masuk </th>
            <th colspan ="2"> Aksi </th>
        </tr>

        <?php
        $no = 1;
        while ($tampil = mysqli_fetch_assoc($result)) {
        ?>
            <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $tampil['nik']; ?></td>
                <td width="100"><?php echo $tampil['nama']; ?></td>
                <td width="100"><?php echo $tampil['tgl_lahir']; ?></td>
                <td><?php echo $tampil['departemen']; ?></td>
                <td><?php echo $tampil['alamat']; ?></td>
                <td><?php echo $tampil['no_hp']; ?></td>
                <td><?php echo $tampil['tgl_masuk']; ?></td>
                <td>
                    <a href="ubah_karyawan.php?nik=<?php echo $tampil['nik']; ?>" onclick="return confirm('Yakin Ubah Data?')">Ubah</a></td>
                <td>
                    <a href="hapus_karyawan.php?nik=<?php echo $tampil['nik']; ?>" onclick="return confirm('Yakin Hapus Data?')">Hapus</a></td>
            </tr>

        <?php
            $no++;
        }
        ?>
        </tr>
    </table>
</body>
</html>
