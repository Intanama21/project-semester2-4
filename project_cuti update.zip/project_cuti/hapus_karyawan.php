<?php
session_start();
if(!isset($_SESSION['id_user']))
{
    echo "<script>
        alert('Silakan login dahulu');		
        window.location = '../project_cuti/login.php'; 
       </script>";
    exit;	
}
include "koneksi.php";


if(isset($_GET['nik'])) {
    $nik = $_GET['nik']; 

    $query = "DELETE FROM karyawan WHERE nik = '$nik'";
    $result = mysqli_query($koneksi, $query);

    if($result) { 
      
        header('Location: tampil_karyawan.php');
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($koneksi);
    }
}
?>


