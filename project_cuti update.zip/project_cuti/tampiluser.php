<!DOCTYPE html>
<html>
<head>
    <title>DATA USER</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h3 {
            color: #333;
        }

        form {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
        }

        table tr {
            margin-bottom: 10px;
            
        }

        table td {
            padding: 8px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="submit"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<h2 align="center">DATA USER</h2>
<form action="" method="post">
    <table>
        <tr>
            <td width="120"> ID User</td>
            <td> <input type="text" name="id_user"></td>
</tr>
<tr>
            <td>Nama Email</td>
            <td> <input type="text" name="nama_email"></td>
</tr>
<tr>
            <td>Kata Sandi</td>
            <td> <input type="password" name="sandi"></td>
</tr>
<tr><td> Masuk Sebagai <select name=grup>
			<option value=Admin>Admin</option>
			<option value=Karyawan>Karyawan</option>
   </select></td></tr>
<tr>
    <td> <input type="submit" name="save" value="simpan">
</table>
    </body>
    <?php
    session_start();
    if(!isset($_SESSION['id']))
    {
        echo "<script>
            alert('Silakan login dahulu');		
            window.location = '../project_cuti/login.php'; 
           </script>";
        exit;	
    }
include "koneksi.php";

if(isset($_POST['save'])){
    $id_user = $_POST['id'];
    $nama_email = $_POST['nama'];
    $kata_sandi = $_POST['sandi'];

    // Menggunakan MD5 untuk menghash kata sandi sebelum disimpan
    $hashed_password = md5($kata_sandi);

    mysqli_query($koneksi, "INSERT INTO user (id_user, nama_email, kata_sandi) VALUES ('$id_user', '$nama_email', '$hashed_password')");
    
    echo "Data telah tersimpan";
}
?>

